function createBinaryInputs(containerId, outputId, isAscii = false) {
  const container = document.getElementById(containerId);
  for (let i = 0; i < 8; i++) {
    const input = document.createElement("input");
    input.type = "number";
    input.min = 0;
    input.max = 1;
    input.value = 0;
    input.maxLength = 1;

    input.addEventListener("input", () => {
      const bits = [...container.querySelectorAll("input")].map(i => i.value || "0");
      const value = parseInt(bits.join(""), 2);
      if (!isAscii) {
        document.getElementById(outputId).textContent = value;
      } else {
        const char = value >= 32 && value <= 126 ? String.fromCharCode(value) : `Non-printable (${value})`;
        document.getElementById(outputId).textContent = char;
      }
    });

    container.appendChild(input);
  }
}

createBinaryInputs("binary-input-decimal", "decimal-output");
createBinaryInputs("binary-input-ascii", "ascii-output", true);
